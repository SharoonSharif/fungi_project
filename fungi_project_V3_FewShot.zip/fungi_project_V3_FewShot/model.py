import torch
import torch.nn as nn
from torchvision.models import resnet18, ResNet18_Weights

class FeatureEncoder(nn.Module):
    def __init__(self, pretrained=True):
        super().__init__()
        # Fix the ResNet loading
        if pretrained:
            backbone = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1)
        else:
            backbone = resnet18(weights=None)
        
        # Remove the final classification layer
        self.features = nn.Sequential(*list(backbone.children())[:-1])
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.feat_dim = 512  # ResNet18 feature dimension
        
    def forward(self, x):
        x = self.features(x)
        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        return x

class ProtoNetHead(nn.Module):
    def __init__(self):
        super().__init__()
        
    def forward(self, support_features, support_labels, query_features, N_way, K_shot):
        """
        Compute prototypical network predictions
        
        Args:
            support_features: [N*K, feat_dim]
            support_labels: [N*K]
            query_features: [N*Q, feat_dim]
            N_way: number of classes
            K_shot: number of support examples per class
        """
        # Compute prototypes (class centroids)
        prototypes = []
        for class_id in range(N_way):
            # Get support examples for this class
            class_mask = (support_labels == class_id)
            class_features = support_features[class_mask]
            # Compute prototype as mean of support features
            prototype = class_features.mean(dim=0)
            prototypes.append(prototype)
        
        prototypes = torch.stack(prototypes)  # [N_way, feat_dim]
        
        # Compute distances from queries to prototypes
        # Using negative squared euclidean distance as logits
        query_features = query_features.unsqueeze(1)  # [N*Q, 1, feat_dim]
        prototypes = prototypes.unsqueeze(0)          # [1, N_way, feat_dim]
        
        distances = torch.sum((query_features - prototypes) ** 2, dim=2)  # [N*Q, N_way]
        logits = -distances  # Convert to logits (negative distance)
        
        return logits