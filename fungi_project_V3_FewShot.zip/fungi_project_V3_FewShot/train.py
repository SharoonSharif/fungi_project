import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
from tqdm import tqdm
from model import FeatureEncoder, ProtoNetHead
from data_loader import FungiDataset, FewShotEpisodeDataset
from torch.utils.data import DataLoader

def train_fewshot(
    data_root,
    device="cuda",
    N_way=5, K_shot=5, Q_query=15,
    episodes=200, epochs=10,
    lr=1e-3
):
    # prepare datasets
    base_ds = FungiDataset(data_root, split="train",
        transform=torchvision.transforms.Compose([
            torchvision.transforms.Resize(224),
            torchvision.transforms.ToTensor(),
        ]))
    epi_ds  = FewShotEpisodeDataset(
        base_ds, N_way, K_shot, Q_query, episodes_per_epoch=episodes)
    loader  = DataLoader(epi_ds, batch_size=1, shuffle=True)

    # model
    encoder = FeatureEncoder(pretrained=True).to(device)
    head    = ProtoNetHead().to(device)
    optimizer = optim.Adam(encoder.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()

    for ep in range(epochs):
        encoder.train()
        tot_loss = 0
        tot_acc  = 0
        for batch in tqdm(loader, desc=f"Epoch {ep+1}/{epochs}"):
            support_x = batch["support_x"].squeeze(0).to(device)
            support_y = batch["support_y"].squeeze(0).to(device)
            query_x   = batch["query_x"].squeeze(0).to(device)
            query_y   = batch["query_y"].squeeze(0).to(device)

            # embed
            s_z = encoder(support_x)
            q_z = encoder(query_x)

            # logits & loss
            logits = head(s_z, support_y, q_z, N_way, K_shot)
            loss   = criterion(logits, query_y)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            tot_loss += loss.item()
            tot_acc  += (logits.argmax(1) == query_y).float().mean().item()
        
        print(f"> Epoch {ep+1}: Loss={tot_loss/episodes:.3f}, Acc={tot_acc/episodes:.3f}")

    torch.save(encoder.state_dict(), "models/fs_encoder.pth")
    print("🗄️  Encoder saved.")
