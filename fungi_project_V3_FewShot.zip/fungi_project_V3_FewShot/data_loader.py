import os
import random
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms

class FungiDataset(Dataset):
    def __init__(self, root_dir, split="train", transform=None):
        self.root = os.path.join(root_dir, split)
        self.transform = transform or transforms.ToTensor()
        self.samples = []
        self.class_to_idx = {}
        
        # Get all directories (class folders) and filter out system files
        all_items = os.listdir(self.root)
        class_dirs = []
        
        for item in all_items:
            item_path = os.path.join(self.root, item)
            # Only include directories and skip hidden/system files
            if os.path.isdir(item_path) and not item.startswith('.'):
                class_dirs.append(item)
        
        class_dirs.sort()  # Ensure consistent ordering
        
        for idx, cls in enumerate(class_dirs):
            self.class_to_idx[cls] = idx
            cls_folder = os.path.join(self.root, cls)
            
            # Get all files in the class folder
            for fn in os.listdir(cls_folder):
                # Skip system files and non-image files
                if fn.startswith('.') or fn.lower() in ['thumbs.db', 'desktop.ini']:
                    continue
                
                # Only include common image file extensions
                if fn.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif', '.gif')):
                    file_path = os.path.join(cls_folder, fn)
                    self.samples.append((file_path, idx))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, i):
        path, label = self.samples[i]
        try:
            img = Image.open(path).convert("RGB")
            return self.transform(img), label
        except Exception as e:
            print(f"Error loading image {path}: {e}")
            # Return a dummy image if loading fails
            dummy_img = Image.new('RGB', (224, 224), color='black')
            return self.transform(dummy_img), label

class FewShotEpisodeDataset(Dataset):
    """
    Produces episodes for N-way K-shot few-shot learning.
    Each item is a dict: {
        'support_x': Tensor [N*K, C,H,W],
        'support_y': Tensor [N*K],
        'query_x': Tensor [N*Q, C,H,W],
        'query_y': Tensor [N*Q]
    }
    """
    def __init__(self, base_dataset, N_way=5, K_shot=5, Q_query=15, episodes_per_epoch=100):
        self.ds = base_dataset
        self.N = N_way
        self.K = K_shot
        self.Q = Q_query
        self.episodes = episodes_per_epoch
        
        # invert class→samples mapping
        self.by_class = {}
        for i in range(len(self.ds)):
            img, lbl = self.ds[i]  # Fixed: use = instead of in
            if lbl not in self.by_class:
                self.by_class[lbl] = []
            self.by_class[lbl].append(img)
        
        # Check if we have enough classes and samples
        assert len(self.by_class) >= self.N, f"Not enough classes for {self.N}-way. Found {len(self.by_class)} classes"
        
        for class_id, samples in self.by_class.items():
            if len(samples) < (self.K + self.Q):
                print(f"Warning: Class {class_id} has only {len(samples)} samples, need {self.K + self.Q}")

    def __len__(self):
        return self.episodes

    def __getitem__(self, idx):
        # Filter classes that have enough samples
        valid_classes = [c for c, samples in self.by_class.items() 
                        if len(samples) >= (self.K + self.Q)]
        
        if len(valid_classes) < self.N:
            raise ValueError(f"Not enough classes with sufficient samples. Need {self.N}, have {len(valid_classes)}")
        
        # sample N classes
        classes = random.sample(valid_classes, self.N)
        support_x, support_y = [], []
        query_x, query_y = [], []
        
        for new_label, original_class in enumerate(classes):
            imgs = random.sample(self.by_class[original_class], self.K + self.Q)
            sup, qry = imgs[:self.K], imgs[self.K:]
            
            support_x.extend(sup)
            query_x.extend(qry)
            support_y.extend([new_label] * self.K)  # Use 0,1,2,... labels for episode
            query_y.extend([new_label] * self.Q)
        
        # stack
        import torch
        support_x = torch.stack(support_x)
        query_x = torch.stack(query_x)
        support_y = torch.tensor(support_y)
        query_y = torch.tensor(query_y)
        
        return {
            "support_x": support_x,
            "support_y": support_y,
            "query_x": query_x,
            "query_y": query_y,
        }