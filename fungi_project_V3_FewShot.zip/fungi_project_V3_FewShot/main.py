# src/main.py
import argparse
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as T
from tqdm import tqdm
from torch.utils.data import DataLoader
from model import FeatureEncoder, ProtoNetHead
from data_loader import FungiDataset, FewShotEpisodeDataset

def train_fewshot(
    data_root,
    device="cuda",
    N_way=5, K_shot=3, Q_query=5,  # Reduced to work with smaller classes
    episodes=100, epochs=5,  # Reduced for faster training
    lr=1e-3
):
    # Check device availability
    if device == "cuda" and not torch.cuda.is_available():
        print("CUDA not available, using CPU")
        device = "cpu"
    
    print(f"Using device: {device}")
    print(f"Few-shot setup: {N_way}-way {K_shot}-shot with {Q_query} query samples")
    
    # prepare datasets
    transform = T.Compose([
        T.Resize((224, 224)),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])  # ImageNet normalization
    ])
    
    base_ds = FungiDataset(
        data_root, split="train",
        transform=transform
    )
    
    print(f"Dataset loaded with {len(base_ds)} samples")
    
    # Check how many classes have enough samples
    class_counts = {}
    for _, label in base_ds.samples:
        class_counts[label] = class_counts.get(label, 0) + 1
    
    valid_classes = [cls for cls, count in class_counts.items() if count >= (K_shot + Q_query)]
    print(f"Classes with enough samples ({K_shot + Q_query}+): {len(valid_classes)}/{len(class_counts)}")
    
    if len(valid_classes) < N_way:
        print(f"Warning: Only {len(valid_classes)} classes have enough samples for {N_way}-way learning")
        N_way = min(N_way, len(valid_classes))
        print(f"Adjusting to {N_way}-way learning")
    
    epi_ds = FewShotEpisodeDataset(
        base_ds, N_way, K_shot, Q_query,
        episodes_per_epoch=episodes
    )
    loader = DataLoader(epi_ds, batch_size=1, shuffle=True)
    
    # model
    encoder = FeatureEncoder(pretrained=True).to(device)
    head = ProtoNetHead().to(device)
    
    # Optimizer for both encoder and head (though head has no parameters)
    optimizer = optim.Adam(encoder.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()
    
    print("Starting training...")
    
    for ep in range(epochs):
        encoder.train()
        tot_loss = 0.0
        tot_acc = 0.0
        
        for batch in tqdm(loader, desc=f"Epoch {ep+1}/{epochs}"):
            support_x = batch["support_x"].squeeze(0).to(device)
            support_y = batch["support_y"].squeeze(0).to(device)
            query_x = batch["query_x"].squeeze(0).to(device)
            query_y = batch["query_y"].squeeze(0).to(device)
            
            # embed
            s_z = encoder(support_x)
            q_z = encoder(query_x)
            
            # logits & loss
            logits = head(s_z, support_y, q_z, N_way, K_shot)
            loss = criterion(logits, query_y)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            tot_loss += loss.item()
            tot_acc += (logits.argmax(1) == query_y).float().mean().item()
        
        avg_loss = tot_loss / episodes
        avg_acc = tot_acc / episodes
        print(f"> Epoch {ep+1}: Loss={avg_loss:.3f}, Acc={avg_acc:.3f}")
    
    # Create models directory if it doesn't exist
    import os
    os.makedirs("models", exist_ok=True)
    
    # save
    torch.save(encoder.state_dict(), "models/fs_encoder.pth")
    print("🗄️ Encoder saved to models/fs_encoder.pth")

def parse_args():
    p = argparse.ArgumentParser(description="Few-Shot Fungi Training")
    p.add_argument("--data_root", 
                   default="/Users/sharoonsharif/Documents/fungi_project_FewShot/data/split_mind_funga",
                   help="Path to the fungi dataset")
    p.add_argument("--device", default="cuda", help="cuda or cpu")
    p.add_argument("--N_way", type=int, default=5)
    p.add_argument("--K_shot", type=int, default=3)  # Reduced default
    p.add_argument("--Q_query", type=int, default=5)  # Reduced default
    p.add_argument("--episodes", type=int, default=100)  # Reduced default
    p.add_argument("--epochs", type=int, default=5)  # Reduced default
    p.add_argument("--lr", type=float, default=1e-3)
    return p.parse_args()

def main():
    print("🚀 Running few-shot training…")
    args = parse_args()
    train_fewshot(
        data_root=args.data_root,
        device=args.device,
        N_way=args.N_way,
        K_shot=args.K_shot,
        Q_query=args.Q_query,
        episodes=args.episodes,
        epochs=args.epochs,
        lr=args.lr
    )

if __name__ == "__main__":
    main()