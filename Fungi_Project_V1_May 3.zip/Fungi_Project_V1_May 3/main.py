import os
import sys
import numpy as np
import torch
from torch.utils.data import DataLoader, WeightedRandomSampler
from torch.optim.lr_scheduler import ReduceLROnPlateau

# ensure src is importable
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), ".")))

from data_loader import FungiDataset, get_transforms
from model import FungiClassifier
from train import train_model
from eval import evaluate


def main():
    # device
    device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
    print("Using device:", device)

    # data paths
    data_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../data/split_mind_funga"))

    # train dataset
    train_ds = FungiDataset(
        root_dir=os.path.join(data_dir, "train"),
        transforms=get_transforms(train=True)
    )
    # class weights
    counts = np.bincount([label for _, label in train_ds.samples], minlength=len(train_ds.class_to_idx))
    weights = np.zeros_like(counts, dtype=float)
    mask = counts > 0
    weights[mask] = 1.0 / counts[mask]
    weights[mask] *= mask.sum() / weights[mask].sum()

    samp_weights = [weights[label] for _, label in train_ds.samples]
    sampler = WeightedRandomSampler(samp_weights, num_samples=len(samp_weights), replacement=True)

    # val dataset
    val_ds = FungiDataset(
        root_dir=os.path.join(data_dir, "val"),
        transforms=get_transforms(train=False),
        class_to_idx=train_ds.class_to_idx
    )

    # loaders
    train_loader = DataLoader(
        train_ds, batch_size=16, sampler=sampler,
        num_workers=0, pin_memory=False
    )
    val_loader = DataLoader(
        val_ds, batch_size=16, shuffle=False,
        num_workers=0, pin_memory=False
    )

    # model, loss, optimizer, scheduler
    model = FungiClassifier(num_classes=len(train_ds.class_to_idx)).to(device)
    weight_tensor = torch.tensor(weights, dtype=torch.float).to(device)
    criterion = torch.nn.CrossEntropyLoss(weight=weight_tensor)
    optimizer = torch.optim.Adam(model.parameters(), lr=3e-4)
    scheduler = ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=2)

    # train
    best_model = train_model(
        model, train_loader, val_loader,
        optimizer, criterion, device,
        epochs=10, scheduler=scheduler,
        early_stopping_patience=5
    )

    # save
    os.makedirs("models", exist_ok=True)
    save_path = os.path.join("models", "resnet18_fungi.pth")
    torch.save(best_model.state_dict(), save_path)
    print(f"✅ Model saved to {save_path}")

    # evaluate
    best_model.load_state_dict(torch.load(save_path, map_location=device))
    best_model.eval()
    print("\n=== Evaluating on Val Set ===")
    evaluate(best_model, val_loader, device, list(train_ds.class_to_idx.keys()))


if __name__ == "__main__":
    main()