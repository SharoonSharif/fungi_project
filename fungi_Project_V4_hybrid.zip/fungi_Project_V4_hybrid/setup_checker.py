#!/usr/bin/env python3
"""
Setup verification script for fungi classification experiment
"""

import os
import sys
import torch
import pandas as pd
from pathlib import Path

def check_python_packages():
    """Check if required packages are installed"""
    print("📦 Checking Python packages...")
    required_packages = [
        'torch', 'torchvision', 'PIL', 'pandas', 'numpy', 
        'sklearn', 'matplotlib', 'seaborn', 'tqdm'
    ]
    
    missing = []
    for package in required_packages:
        try:
            __import__(package)
            print(f"  ✅ {package}")
        except ImportError:
            print(f"  ❌ {package}")
            missing.append(package)
    
    if missing:
        print(f"\n⚠️  Missing packages: {', '.join(missing)}")
        print("Install them with: pip install " + " ".join(missing))
        return False
    
    print("✅ All required packages are installed")
    return True

def check_pytorch_setup():
    """Check PyTorch and device availability"""
    print("\n🔥 Checking PyTorch setup...")
    print(f"  PyTorch version: {torch.__version__}")
    
    # Check CUDA
    if torch.cuda.is_available():
        print(f"  ✅ CUDA available: {torch.cuda.get_device_name(0)}")
        print(f"  GPU memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
    else:
        print("  ⚠️  CUDA not available")
    
    # Check MPS (Apple Silicon)
    if hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
        print("  ✅ MPS (Apple Silicon) available")
    else:
        print("  ⚠️  MPS not available")
    
    print("  ✅ CPU always available")
    return True

def check_data_structure(data_root):
    """Check if data is properly structured"""
    print(f"\n📁 Checking data structure in {data_root}...")
    
    if not os.path.exists(data_root):
        print(f"  ❌ Data root {data_root} does not exist")
        return False
    
    # Check for required CSV files
    train_csv = os.path.join(data_root, "train.csv")
    val_csv = os.path.join(data_root, "val.csv")
    
    if not os.path.exists(train_csv):
        print(f"  ❌ train.csv not found at {train_csv}")
        return False
    else:
        print(f"  ✅ train.csv found")
    
    if not os.path.exists(val_csv):
        print(f"  ❌ val.csv not found at {val_csv}")
        return False
    else:
        print(f"  ✅ val.csv found")
    
    # Check CSV structure
    try:
        train_df = pd.read_csv(train_csv)
        val_df = pd.read_csv(val_csv)
        
        # Check required columns
        required_cols = ['filepath', 'label']
        for col in required_cols:
            if col not in train_df.columns:
                print(f"  ❌ Column '{col}' missing from train.csv")
                return False
            if col not in val_df.columns:
                print(f"  ❌ Column '{col}' missing from val.csv")
                return False
        
        print(f"  ✅ CSV structure valid")
        print(f"  📊 Training samples: {len(train_df)}")
        print(f"  📊 Validation samples: {len(val_df)}")
        print(f"  📊 Training classes: {train_df['label'].nunique()}")
        print(f"  📊 Validation classes: {val_df['label'].nunique()}")
        
        # Check if image files exist (sample a few)
        sample_size = min(10, len(train_df))
        sample_files = train_df['filepath'].sample(sample_size)
        missing_files = 0
        
        for filepath in sample_files:
            full_path = os.path.join(data_root, filepath)
            if not os.path.exists(full_path):
                missing_files += 1
        
        if missing_files > 0:
            print(f"  ⚠️  {missing_files}/{sample_size} sampled image files are missing")
        else:
            print(f"  ✅ All sampled image files ({sample_size}/{sample_size}) exist")
        
        return missing_files == 0
        
    except Exception as e:
        print(f"  ❌ Error reading CSV files: {e}")
        return False

def check_code_files():
    """Check if required Python files are present"""
    print(f"\n📝 Checking code files...")
    
    required_files = [
        'model.py',
        'data_loader.py', 
        'enhanced_hybrid_trainer.py',
        'comprehensive_eval.py'
    ]
    
    missing = []
    for file in required_files:
        if os.path.exists(file):
            print(f"  ✅ {file}")
        else:
            print(f"  ❌ {file}")
            missing.append(file)
    
    if missing:
        print(f"\n⚠️  Missing files: {', '.join(missing)}")
        return False
    
    return True

def check_disk_space():
    """Check available disk space"""
    print(f"\n💾 Checking disk space...")
    
    try:
        import shutil
        total, used, free = shutil.disk_usage(".")
        
        free_gb = free / (1024**3)
        total_gb = total / (1024**3)
        
        print(f"  Total space: {total_gb:.1f} GB")
        print(f"  Free space: {free_gb:.1f} GB")
        
        if free_gb < 2.0:
            print(f"  ⚠️  Low disk space ({free_gb:.1f} GB)")
            return False
        else:
            print(f"  ✅ Sufficient disk space")
            return True
            
    except Exception as e:
        print(f"  ⚠️  Could not check disk space: {e}")
        return True  # Don't fail the check

def suggest_configuration(data_root):
    """Suggest optimal configuration based on system"""
    print(f"\n🎯 Configuration suggestions...")
    
    # Device suggestion
    if torch.cuda.is_available():
        device = "cuda"
        batch_size = 64
    elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
        device = "mps"
        batch_size = 32
    else:
        device = "cpu"
        batch_size = 16
    
    print(f"  Recommended device: {device}")
    print(f"  Recommended batch size: {batch_size}")
    
    # Check dataset size for epoch recommendations
    try:
        train_csv = os.path.join(data_root, "train.csv")
        if os.path.exists(train_csv):
            train_df = pd.read_csv(train_csv)
            num_samples = len(train_df)
            
            if num_samples > 10000:
                stage1_epochs = 15
                stage2_epochs = 8
            elif num_samples > 5000:
                stage1_epochs = 20
                stage2_epochs = 10
            else:
                stage1_epochs = 25
                stage2_epochs = 12
            
            print(f"  Recommended Stage 1 epochs: {stage1_epochs}")
            print(f"  Recommended Stage 2 epochs: {stage2_epochs}")
            
            # Estimate training time
            samples_per_epoch = num_samples
            time_per_sample = 0.01 if device == "cuda" else 0.05 if device == "mps" else 0.2
            estimated_time = (samples_per_epoch * time_per_sample * (stage1_epochs + stage2_epochs)) / 60
            
            print(f"  Estimated training time: {estimated_time:.1f} minutes")
    
    except Exception as e:
        print(f"  Could not analyze dataset for recommendations: {e}")

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Verify setup for fungi classification experiment")
    parser.add_argument("--data_root", type=str, default="data/split_mind_funga", 
                       help="Path to dataset root")
    args = parser.parse_args()
    
    print("🍄 FUNGI CLASSIFICATION SETUP VERIFICATION")
    print("="*80)
    
    checks = [
        check_python_packages(),
        check_pytorch_setup(), 
        check_code_files(),
        check_data_structure(args.data_root),
        check_disk_space()
    ]
    
    print("\n" + "="*80)
    
    if all(checks):
        print("🎉 ALL CHECKS PASSED!")
        print("Your setup is ready for the experiment.")
        suggest_configuration(args.data_root)
        
        print(f"\n📋 Quick start command:")
        print(f"python run_hybrid_experiment.py {args.data_root}")
        
    else:
        print("❌ SOME CHECKS FAILED!")
        print("Please fix the issues above before running the experiment.")
    
    print("="*80)

if __name__ == "__main__":
    main()