#!/usr/bin/env python3
"""
Script to run the complete hybrid training experiment and comparison
"""

import os
import sys
import subprocess
import time
import argparse

def run_command(cmd, description):
    """Run a command and handle errors"""
    print(f"\n{'='*60}")
    print(f"RUNNING: {description}")
    print(f"COMMAND: {cmd}")
    print(f"{'='*60}")
    
    start_time = time.time()
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    end_time = time.time()
    
    duration = end_time - start_time
    print(f"Duration: {duration:.1f} seconds")
    
    if result.returncode == 0:
        print(f"✅ SUCCESS: {description}")
        if result.stdout:
            print("STDOUT:")
            print(result.stdout)
    else:
        print(f"❌ FAILED: {description}")
        print("STDERR:")
        print(result.stderr)
        if result.stdout:
            print("STDOUT:")
            print(result.stdout)
        return False
    
    return True

def main():
    parser = argparse.ArgumentParser(description="Run complete hybrid training experiment")
    parser.add_argument("data_root", type=str, help="Path to dataset root")
    parser.add_argument("--epochs_stage1", type=int, default=20, help="Stage 1 epochs")
    parser.add_argument("--epochs_stage2", type=int, default=10, help="Stage 2 epochs")
    parser.add_argument("--batch_size", type=int, default=64, help="Batch size")
    parser.add_argument("--num_classes", type=int, default=488, help="Number of classes")
    parser.add_argument("--model_arch", type=str, default="resnet18", choices=["resnet18", "resnet50"])
    parser.add_argument("--device", type=str, default=None, help="Device (cuda/cpu/mps/auto)")
    parser.add_argument("--skip_training", action="store_true", help="Skip training, only evaluate")
    parser.add_argument("--skip_comparison", action="store_true", help="Skip final comparison")
    
    args = parser.parse_args()
    
    print("🍄 FUNGI CLASSIFICATION HYBRID TRAINING EXPERIMENT")
    print("="*80)
    print(f"Data root: {args.data_root}")
    print(f"Architecture: {args.model_arch}")
    print(f"Stage 1 epochs: {args.epochs_stage1}")
    print(f"Stage 2 epochs: {args.epochs_stage2}")
    print(f"Batch size: {args.batch_size}")
    print(f"Device: {args.device or 'auto-detect'}")
    print("="*80)
    
    # Check if data directory exists
    if not os.path.exists(args.data_root):
        print(f"❌ ERROR: Data directory {args.data_root} does not exist!")
        return 1
    
    # Check for required files
    train_csv = os.path.join(args.data_root, "train.csv")
    val_csv = os.path.join(args.data_root, "val.csv")
    
    if not os.path.exists(train_csv):
        print(f"❌ ERROR: Training CSV {train_csv} not found!")
        return 1
    
    if not os.path.exists(val_csv):
        print(f"❌ ERROR: Validation CSV {val_csv} not found!")
        return 1
    
    success = True
    
    # Step 1: Run hybrid training
    if not args.skip_training:
        device_arg = f"--device {args.device}" if args.device else ""
        
        hybrid_cmd = (
            f"python enhanced_hybrid_trainer.py {args.data_root} "
            f"--epochs_stage1 {args.epochs_stage1} "
            f"--epochs_stage2 {args.epochs_stage2} "
            f"--batch_size {args.batch_size} "
            f"--num_classes {args.num_classes} "
            f"--model_arch {args.model_arch} "
            f"{device_arg}"
        )
        
        success &= run_command(hybrid_cmd, "Hybrid Training")
    else:
        print("\n⏭️  SKIPPING TRAINING (--skip_training flag set)")
    
    # Step 2: Evaluate hybrid model
    if success and os.path.exists("hybrid_longtail_final.pth"):
        device_arg = f"--device {args.device}" if args.device else ""
        
        eval_cmd = (
            f"python comprehensive_eval.py {args.data_root} "
            f"--models hybrid_longtail_final.pth "
            f"--model_names 'Hybrid_Long-Tail' "
            f"--model_types hybrid "
            f"--num_classes {args.num_classes} "
            f"--batch_size {args.batch_size} "
            f"--model_arch {args.model_arch} "
            f"--detailed "
            f"{device_arg}"
        )
        
        success &= run_command(eval_cmd, "Hybrid Model Evaluation")
    elif not args.skip_training:
        print("❌ Hybrid model file not found - training may have failed")
        success = False
    
    # Step 3: Compare with existing models (if available)
    if success and not args.skip_comparison:
        print(f"\n{'='*60}")
        print("SEARCHING FOR EXISTING MODELS TO COMPARE")
        print(f"{'='*60}")
        
        # Look for existing model files
        existing_models = []
        model_names = []
        model_types = []
        
        # Check for CNN model
        cnn_paths = ["cnn_best_model.pth", "best_stage_1_model.pth", "resnet18_fungi.pth"]
        for path in cnn_paths:
            if os.path.exists(path):
                existing_models.append(path)
                model_names.append(f"CNN_({os.path.basename(path)})")
                model_types.append("cnn")
                print(f"✅ Found CNN model: {path}")
                break
        
        # Check for few-shot model
        fs_paths = ["fewshot_encoder.pth", "fs_encoder.pth"]
        for path in fs_paths:
            if os.path.exists(path):
                existing_models.append(path)
                model_names.append(f"Few-Shot_({os.path.basename(path)})")
                model_types.append("fewshot")
                print(f"✅ Found Few-Shot model: {path}")
                break
        
        # Add hybrid model
        if os.path.exists("hybrid_longtail_final.pth"):
            existing_models.append("hybrid_longtail_final.pth")
            model_names.append("Hybrid_Long-Tail")
            model_types.append("hybrid")
            print(f"✅ Found Hybrid model: hybrid_longtail_final.pth")
        
        # Run comparison if we have multiple models
        if len(existing_models) > 1:
            device_arg = f"--device {args.device}" if args.device else ""
            
            comparison_cmd = (
                f"python comprehensive_eval.py {args.data_root} "
                f"--models {' '.join(existing_models)} "
                f"--model_names {' '.join(model_names)} "
                f"--model_types {' '.join(model_types)} "
                f"--num_classes {args.num_classes} "
                f"--batch_size {args.batch_size} "
                f"--model_arch {args.model_arch} "
                f"{device_arg}"
            )
            
            success &= run_command(comparison_cmd, "Model Comparison")
        else:
            print("ℹ️  Only one model found - skipping comparison")
    
    # Final summary
    print(f"\n{'='*80}")
    if success:
        print("🎉 EXPERIMENT COMPLETED SUCCESSFULLY!")
        print("="*80)
        print("Generated files:")
        
        files_to_check = [
            "hybrid_longtail_final.pth",
            "best_stage_1_model.pth", 
            "best_stage_2_model.pth",
            "model_comparison.csv"
        ]
        
        for file in files_to_check:
            if os.path.exists(file):
                size = os.path.getsize(file) / (1024*1024)  # MB
                print(f"  ✅ {file} ({size:.1f} MB)")
            else:
                print(f"  ❌ {file} (not found)")
        
        print("\nNext steps:")
        print("1. Check model_comparison.csv for detailed metrics")
        print("2. Use the best model for inference")
        print("3. Consider further hyperparameter tuning if needed")
        
    else:
        print("❌ EXPERIMENT FAILED!")
        print("="*80)
        print("Please check the error messages above and:")
        print("1. Verify your data directory structure")
        print("2. Check that all required Python packages are installed")
        print("3. Ensure sufficient disk space and memory")
        print("4. Try reducing batch size if you encounter OOM errors")
    
    return 0 if success else 1

if __name__ == "__main__":
    exit(main())