import argparse
import os
import torch
import time
import subprocess

def run_command(cmd, description):
    """Run a command and handle errors"""
    print(f"\n{'='*60}")
    print(f"RUNNING: {description}")
    print(f"{'='*60}")
    
    start_time = time.time()
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    end_time = time.time()
    
    duration = end_time - start_time
    print(f"Duration: {duration:.1f} seconds")
    
    if result.returncode == 0:
        print(f"✅ SUCCESS: {description}")
        if result.stdout:
            print(result.stdout)
    else:
        print(f"❌ FAILED: {description}")
        print("STDERR:")
        print(result.stderr)
        return False
    
    return True

def main():
    parser = argparse.ArgumentParser(description="Fungi Long-Tail Training Main Script")
    parser.add_argument("data_root", type=str, help="Path to root of fungi dataset")
    parser.add_argument("--mode", type=str, choices=["cnn", "fewshot", "hybrid", "experiment"], 
                        required=True, help="Select training mode or run full experiment")
    parser.add_argument("--epochs", type=int, default=10, help="Epochs for traditional/fewshot")
    parser.add_argument("--epochs_stage1", type=int, default=20, help="Stage 1 epochs (hybrid only)")
    parser.add_argument("--epochs_stage2", type=int, default=10, help="Stage 2 epochs (hybrid only)")
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--logdir", type=str, default="logs")
    parser.add_argument("--num_classes", type=int, default=488)
    parser.add_argument("--model_arch", type=str, default="resnet18", choices=["resnet18", "resnet50"])
    parser.add_argument("--evaluate", action="store_true", help="Run evaluation after training")
    parser.add_argument("--compare", action="store_true", help="Compare with existing models")
    args = parser.parse_args()

    os.makedirs(args.logdir, exist_ok=True)
    
    print("🍄 FUNGI CLASSIFICATION TRAINING")
    print("="*80)
    print(f"Mode: {args.mode}")
    print(f"Data root: {args.data_root}")
    print(f"Device: {args.device}")
    print("="*80)

    if args.mode == "cnn":
        print("Launching standard CNN training...")
        from train import run_cnn_training
        run_cnn_training(
            data_root=args.data_root,
            epochs=args.epochs,
            batch_size=args.batch_size,
            device=args.device,
            logdir=args.logdir,
        )
        
        if args.evaluate:
            print("\nRunning CNN evaluation...")
            eval_cmd = (
                f"python comprehensive_eval.py {args.data_root} "
                f"--models {os.path.join(args.logdir, 'cnn_best_model.pth')} "
                f"--model_names CNN "
                f"--model_types cnn "
                f"--device {args.device}"
            )
            run_command(eval_cmd, "CNN Evaluation")

    elif args.mode == "fewshot":
        print("Launching Few-Shot training...")
        from train import run_fewshot_training
        run_fewshot_training(
            data_root=args.data_root,
            epochs=args.epochs,
            batch_size=args.batch_size,
            device=args.device,
            logdir=args.logdir,
        )
        
        if args.evaluate:
            print("\nRunning Few-Shot evaluation...")
            eval_cmd = (
                f"python comprehensive_eval.py {args.data_root} "
                f"--models {os.path.join(args.logdir, 'fewshot_encoder.pth')} "
                f"--model_names Few-Shot "
                f"--model_types fewshot "
                f"--device {args.device}"
            )
            run_command(eval_cmd, "Few-Shot Evaluation")

    elif args.mode == "hybrid":
        print("Launching Hybrid Long-Tail Trainer...")
        from enhanced_hybrid_trainer import run_hybrid_training
        run_hybrid_training(
            data_root=args.data_root,
            epochs_stage1=args.epochs_stage1,
            epochs_stage2=args.epochs_stage2,
            batch_size=args.batch_size,
            device=args.device,
            model_arch=args.model_arch,
            num_classes=args.num_classes,
        )
        
        if args.evaluate:
            print("\nRunning Hybrid evaluation...")
            eval_cmd = (
                f"python comprehensive_eval.py {args.data_root} "
                f"--models hybrid_longtail_final.pth "
                f"--model_names Hybrid "
                f"--model_types hybrid "
                f"--device {args.device} "
                f"--model_arch {args.model_arch}"
            )
            run_command(eval_cmd, "Hybrid Evaluation")

    elif args.mode == "experiment":
        print("🧪 RUNNING COMPLETE EXPERIMENT...")
        print("This will run hybrid training + comprehensive evaluation + comparison")
        
        # Step 1: Run hybrid training
        print("\n📍 Step 1: Hybrid Training")
        from enhanced_hybrid_trainer import run_hybrid_training
        model, stage1_acc, stage2_acc = run_hybrid_training(
            data_root=args.data_root,
            epochs_stage1=args.epochs_stage1,
            epochs_stage2=args.epochs_stage2,
            batch_size=args.batch_size,
            device=args.device,
            model_arch=args.model_arch,
            num_classes=args.num_classes,
        )
        
        # Step 2: Comprehensive evaluation
        print("\n📍 Step 2: Comprehensive Evaluation")
        
        # Find existing models for comparison
        existing_models = []
        model_names = []
        model_types = []
        
        # Check for models
        model_files = [
            ("cnn_best_model.pth", "CNN", "cnn"),
            ("fewshot_encoder.pth", "Few-Shot", "fewshot"),
            ("hybrid_longtail_final.pth", "Hybrid", "hybrid")
        ]
        
        for file, name, mtype in model_files:
            if os.path.exists(file):
                existing_models.append(file)
                model_names.append(name)
                model_types.append(mtype)
                print(f"  ✅ Found {name}: {file}")
        
        if len(existing_models) > 0:
            eval_cmd = (
                f"python comprehensive_eval.py {args.data_root} "
                f"--models {' '.join(existing_models)} "
                f"--model_names {' '.join(model_names)} "
                f"--model_types {' '.join(model_types)} "
                f"--device {args.device} "
                f"--model_arch {args.model_arch} "
                f"--detailed"
            )
            run_command(eval_cmd, "Comprehensive Model Comparison")
        
        print("\n🎉 EXPERIMENT COMPLETE!")
        print(f"Hybrid Stage 1 best accuracy: {stage1_acc:.3f}")
        print(f"Hybrid Stage 2 best accuracy: {stage2_acc:.3f}")
        if os.path.exists("model_comparison.csv"):
            print("📊 Results saved to: model_comparison.csv")

    else:
        raise ValueError(f"Unknown mode: {args.mode}")

if __name__ == "__main__":
    main()