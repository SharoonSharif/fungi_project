import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, WeightedRandomSampler
from model import get_model, FeatureEncoder, ProtoNetHead
from data_loader import FungiDataset, FewShotEpisodeDataset, get_class_counts, get_sampler_weights
from tqdm import tqdm
import torchvision.transforms as T
import os

def get_transforms(train=True):
    # Customize your augmentation pipeline as needed
    if train:
        return T.Compose([
            T.Resize((224,224)),
            T.RandomHorizontalFlip(),
            T.RandomVerticalFlip(),
            T.ColorJitter(0.2, 0.2, 0.2, 0.1),
            T.ToTensor(),
        ])
    else:
        return T.Compose([
            T.Resize((224,224)),
            T.ToTensor(),
        ])

def run_cnn_training(
    data_root, epochs=10, batch_size=64, device='cuda', logdir="logs"
):
    print("=== Running Traditional CNN Training ===")
    num_classes = len(get_class_counts(data_root, split='train'))
    # ===> USE RESNET-18 <===
    model = get_model('resnet18', num_classes=num_classes, pretrained=True).to(device)
    # ... rest unchanged ...

    class_counts = get_class_counts(data_root, split='train')
    sampler_weights = get_sampler_weights(class_counts, mode='inv_freq')
    train_ds = FungiDataset(data_root, split='train', transform=get_transforms(train=True))
    train_loader = DataLoader(
        train_ds, batch_size=batch_size,
        sampler=WeightedRandomSampler(sampler_weights, len(train_ds), replacement=True),
        num_workers=4, pin_memory=True
    )

    val_ds = FungiDataset(data_root, split='val', transform=get_transforms(train=False))
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False, num_workers=2)

    optimizer = optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-4)
    loss_fn = nn.CrossEntropyLoss()

    best_val_acc = 0.0
    for epoch in range(epochs):
        model.train()
        total_loss, correct, total = 0.0, 0, 0
        for images, labels in tqdm(train_loader, desc=f"Epoch {epoch+1}/{epochs} [Train]"):
            images, labels = images.to(device), labels.to(device)
            optimizer.zero_grad()
            logits = model(images)
            loss = loss_fn(logits, labels)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * images.size(0)
            correct += (logits.argmax(dim=1) == labels).sum().item()
            total += labels.size(0)
        train_acc = correct / total
        print(f"Train Loss: {total_loss/total:.3f} | Acc: {train_acc:.3f}")

        # Validation
        model.eval()
        val_correct, val_total = 0, 0
        with torch.no_grad():
            for images, labels in val_loader:
                images, labels = images.to(device), labels.to(device)
                logits = model(images)
                preds = logits.argmax(dim=1)
                val_correct += (preds == labels).sum().item()
                val_total += labels.size(0)
        val_acc = val_correct / val_total
        print(f"Val Acc: {val_acc:.3f}")
        # Save best
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(model.state_dict(), os.path.join(logdir, "cnn_best_model.pth"))
    print("=== Training Complete ===")

def run_fewshot_training(
    data_root, epochs=10, batch_size=16, device='cuda', logdir="logs",
    N_way=5, K_shot=5, Q_query=15
):
    print("=== Running Few-Shot Episodic Training ===")
    num_classes = len(get_class_counts(data_root, split='train'))
    encoder = FeatureEncoder('resnet18', pretrained=True).to(device)
    proto_head = ProtoNetHead().to(device)

    train_ds = FewShotEpisodeDataset(
        data_root, N_way=N_way, K_shot=K_shot, Q_query=Q_query, split='train', transform=get_transforms(train=True))
    train_loader = DataLoader(train_ds, batch_size=1, shuffle=True)

    optimizer = optim.Adam(encoder.parameters(), lr=1e-3)
    loss_fn = nn.CrossEntropyLoss()

    for epoch in range(epochs):
        encoder.train()
        total_loss, correct, total = 0.0, 0, 0
        for (support_imgs, support_labels, query_imgs, query_labels) in tqdm(train_loader, desc=f"Epoch {epoch+1}/{epochs} [FewShot]"):
            support_imgs = support_imgs.squeeze(0).to(device)
            support_labels = support_labels.squeeze(0).to(device)
            query_imgs = query_imgs.squeeze(0).to(device)
            query_labels = query_labels.squeeze(0).to(device)

            optimizer.zero_grad()
            support_feats = encoder(support_imgs)
            query_feats = encoder(query_imgs)
            # Compute prototypes per class
            n_way = N_way
            k_shot = K_shot
            proto_list = []
            for i in range(n_way):
                proto = support_feats[support_labels==i].mean(dim=0)
                proto_list.append(proto)
            prototypes = torch.stack(proto_list)  # [N_way, feat_dim]
            # Compute distances
            dists = torch.cdist(query_feats, prototypes)
            logits = -dists
            loss = loss_fn(logits, query_labels)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * query_imgs.size(0)
            correct += (logits.argmax(dim=1) == query_labels).sum().item()
            total += query_labels.size(0)
        train_acc = correct / total
        print(f"FewShot Train Loss: {total_loss/total:.3f} | Acc: {train_acc:.3f}")
        # Save after each epoch
        torch.save(encoder.state_dict(), os.path.join(logdir, "fewshot_encoder.pth"))
    print("=== Few-Shot Training Complete ===")

# You can import these in main.py and call directly
