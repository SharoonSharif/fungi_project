import torch
from torch.utils.data import DataLoader
import numpy as np
from model import get_model, FeatureEncoder
from data_loader import FungiDataset, get_class_counts
import torchvision.transforms as T
import argparse
import os
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    precision_recall_fscore_support, balanced_accuracy_score
)
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def get_transforms():
    return T.Compose([
        T.Resize((224, 224)),
        T.ToTensor(),
    ])

def analyze_class_performance(y_true, y_pred, class_counts):
    """
    Analyze performance by class frequency (head/medium/tail)
    """
    # Calculate per-class metrics
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true, y_pred, average=None, zero_division=0
    )
    
    # Categorize classes by frequency
    head_classes = [i for i, count in enumerate(class_counts) if count >= 50]
    medium_classes = [i for i, count in enumerate(class_counts) if 10 <= count < 50]
    tail_classes = [i for i, count in enumerate(class_counts) if count < 10]
    
    # Calculate category-wise metrics
    def get_category_metrics(class_indices, metric_array):
        if len(class_indices) == 0:
            return 0.0, 0.0, 0
        valid_metrics = [metric_array[i] for i in class_indices if i < len(metric_array)]
        if len(valid_metrics) == 0:
            return 0.0, 0.0, 0
        return np.mean(valid_metrics), np.std(valid_metrics), len(valid_metrics)
    
    head_precision, head_precision_std, head_count = get_category_metrics(head_classes, precision)
    medium_precision, medium_precision_std, medium_count = get_category_metrics(medium_classes, precision)
    tail_precision, tail_precision_std, tail_count = get_category_metrics(tail_classes, precision)
    
    head_recall, head_recall_std, _ = get_category_metrics(head_classes, recall)
    medium_recall, medium_recall_std, _ = get_category_metrics(medium_classes, recall)
    tail_recall, tail_recall_std, _ = get_category_metrics(tail_classes, recall)
    
    head_f1, head_f1_std, _ = get_category_metrics(head_classes, f1)
    medium_f1, medium_f1_std, _ = get_category_metrics(medium_classes, f1)
    tail_f1, tail_f1_std, _ = get_category_metrics(tail_classes, f1)
    
    results = {
        'head': {
            'count': head_count,
            'precision': (head_precision, head_precision_std),
            'recall': (head_recall, head_recall_std),
            'f1': (head_f1, head_f1_std)
        },
        'medium': {
            'count': medium_count,
            'precision': (medium_precision, medium_precision_std),
            'recall': (medium_recall, medium_recall_std),
            'f1': (medium_f1, medium_f1_std)
        },
        'tail': {
            'count': tail_count,
            'precision': (tail_precision, tail_precision_std),
            'recall': (tail_recall, tail_recall_std),
            'f1': (tail_f1, tail_f1_std)
        }
    }
    
    return results

def evaluate_resnet(
    model_path, data_root, split="val", num_classes=488, batch_size=64, 
    device="cuda", model_arch="resnet18", detailed=True
):
    """
    Comprehensive evaluation of ResNet-based models
    """
    print(f"Evaluating {model_arch} model: {model_path}")
    print(f"Device: {device}")
    
    # Load model
    model = get_model(model_arch, num_classes=num_classes)
    state = torch.load(model_path, map_location=device)
    model.load_state_dict(state)
    model.to(device)
    model.eval()
    
    # Load data
    ds = FungiDataset(data_root, split=split, transform=get_transforms())
    loader = DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=2)
    
    # Get class counts for analysis
    class_counts = get_class_counts(data_root, split='train')
    
    # Inference
    all_labels, all_preds, all_probs = [], [], []
    with torch.no_grad():
        for images, labels in loader:
            images = images.to(device)
            logits = model(images)
            probs = torch.softmax(logits, dim=1)
            preds = logits.argmax(dim=1).cpu().numpy()
            
            all_preds.append(preds)
            all_labels.append(labels.numpy())
            all_probs.append(probs.cpu().numpy())
    
    y_true = np.concatenate(all_labels)
    y_pred = np.concatenate(all_preds)
    y_probs = np.concatenate(all_probs)
    
    # Basic metrics
    accuracy = accuracy_score(y_true, y_pred)
    balanced_acc = balanced_accuracy_score(y_true, y_pred)
    
    # Per-class analysis
    class_analysis = analyze_class_performance(y_true, y_pred, class_counts)
    
    # Print results
    print("="*60)
    print("COMPREHENSIVE EVALUATION RESULTS")
    print("="*60)
    print(f"Overall Accuracy: {accuracy:.4f}")
    print(f"Balanced Accuracy: {balanced_acc:.4f}")
    print("-"*60)
    
    print("PERFORMANCE BY CLASS FREQUENCY:")
    for category in ['head', 'medium', 'tail']:
        data = class_analysis[category]
        print(f"\n{category.upper()} CLASSES (≥50, 10-49, <10 samples):")
        print(f"  Count: {data['count']} classes")
        print(f"  Precision: {data['precision'][0]:.3f} ± {data['precision'][1]:.3f}")
        print(f"  Recall:    {data['recall'][0]:.3f} ± {data['recall'][1]:.3f}")
        print(f"  F1-Score:  {data['f1'][0]:.3f} ± {data['f1'][1]:.3f}")
    
    if detailed:
        print("\n" + "="*60)
        print("DETAILED CLASSIFICATION REPORT:")
        print("="*60)
        print(classification_report(y_true, y_pred, digits=4, zero_division=0))
    
    # Return summary for comparison
    return {
        'accuracy': accuracy,
        'balanced_accuracy': balanced_acc,
        'head_recall': class_analysis['head']['recall'][0],
        'medium_recall': class_analysis['medium']['recall'][0],
        'tail_recall': class_analysis['tail']['recall'][0],
        'head_f1': class_analysis['head']['f1'][0],
        'medium_f1': class_analysis['medium']['f1'][0],
        'tail_f1': class_analysis['tail']['f1'][0]
    }

def evaluate_fewshot_encoder(
    encoder_path, data_root, split="val", batch_size=64, device="cuda", detailed=True
):
    """
    Evaluate few-shot encoder using k-NN classification
    """
    print(f"Evaluating Few-Shot Encoder: {encoder_path}")
    print(f"Device: {device}")
    
    encoder = FeatureEncoder('resnet18', pretrained=False)
    encoder.load_state_dict(torch.load(encoder_path, map_location=device))
    encoder.to(device)
    encoder.eval()

    ds = FungiDataset(data_root, split=split, transform=get_transforms())
    loader = DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=2)
    
    class_counts = get_class_counts(data_root, split='train')

    # Extract features
    features, labels = [], []
    with torch.no_grad():
        for images, lbls in loader:
            images = images.to(device)
            feats = encoder(images).cpu().numpy()
            features.append(feats)
            labels.append(lbls.numpy())
    
    X = np.concatenate(features)
    y = np.concatenate(labels)
    
    # Use k-NN for classification
    from sklearn.neighbors import KNeighborsClassifier
    knn = KNeighborsClassifier(n_neighbors=5)
    knn.fit(X, y)
    y_pred = knn.predict(X)

    # Calculate metrics
    accuracy = accuracy_score(y, y_pred)
    balanced_acc = balanced_accuracy_score(y, y_pred)
    class_analysis = analyze_class_performance(y, y_pred, class_counts)
    
    print("="*60)
    print("FEW-SHOT ENCODER EVALUATION (k-NN)")
    print("="*60)
    print(f"Overall Accuracy: {accuracy:.4f}")
    print(f"Balanced Accuracy: {balanced_acc:.4f}")
    print("-"*60)
    
    print("PERFORMANCE BY CLASS FREQUENCY:")
    for category in ['head', 'medium', 'tail']:
        data = class_analysis[category]
        print(f"\n{category.upper()} CLASSES:")
        print(f"  Count: {data['count']} classes")
        print(f"  Precision: {data['precision'][0]:.3f} ± {data['precision'][1]:.3f}")
        print(f"  Recall:    {data['recall'][0]:.3f} ± {data['recall'][1]:.3f}")
        print(f"  F1-Score:  {data['f1'][0]:.3f} ± {data['f1'][1]:.3f}")

    if detailed:
        print("\n" + "="*60)
        print("DETAILED CLASSIFICATION REPORT:")
        print("="*60)
        print(classification_report(y, y_pred, digits=4, zero_division=0))
    
    return {
        'accuracy': accuracy,
        'balanced_accuracy': balanced_acc,
        'head_recall': class_analysis['head']['recall'][0],
        'medium_recall': class_analysis['medium']['recall'][0],
        'tail_recall': class_analysis['tail']['recall'][0],
        'head_f1': class_analysis['head']['f1'][0],
        'medium_f1': class_analysis['medium']['f1'][0],
        'tail_f1': class_analysis['tail']['f1'][0]
    }

def compare_models(results_dict):
    """
    Create comparison table of all models
    """
    print("\n" + "="*80)
    print("MODEL COMPARISON SUMMARY")
    print("="*80)
    
    # Create comparison DataFrame
    df_data = []
    for model_name, results in results_dict.items():
        df_data.append({
            'Model': model_name,
            'Overall Acc': f"{results['accuracy']:.3f}",
            'Balanced Acc': f"{results['balanced_accuracy']:.3f}",
            'Head Recall': f"{results['head_recall']:.3f}",
            'Medium Recall': f"{results['medium_recall']:.3f}",
            'Tail Recall': f"{results['tail_recall']:.3f}",
            'Head F1': f"{results['head_f1']:.3f}",
            'Medium F1': f"{results['medium_f1']:.3f}",
            'Tail F1': f"{results['tail_f1']:.3f}"
        })
    
    df = pd.DataFrame(df_data)
    print(df.to_string(index=False))
    
    # Save to CSV
    df.to_csv('model_comparison.csv', index=False)
    print(f"\nComparison saved to: model_comparison.csv")

def main():
    parser = argparse.ArgumentParser(description="Comprehensive Model Evaluation")
    parser.add_argument("data_root", type=str, help="Dataset root directory")
    parser.add_argument("--models", nargs="+", help="List of model paths to evaluate")
    parser.add_argument("--model_names", nargs="+", help="Names for the models")
    parser.add_argument("--model_types", nargs="+", choices=["cnn", "hybrid", "fewshot"], 
                        help="Types of models")
    parser.add_argument("--split", type=str, default="val", help="Dataset split to evaluate")
    parser.add_argument("--num_classes", type=int, default=488, help="Number of classes")
    parser.add_argument("--batch_size", type=int, default=64, help="Batch size")
    parser.add_argument("--device", type=str, default=None, help="Device (cuda/cpu/auto)")
    parser.add_argument("--model_arch", type=str, default="resnet18", choices=["resnet18", "resnet50"])
    parser.add_argument("--detailed", action="store_true", help="Show detailed classification reports")
    
    args = parser.parse_args()
    
    # Auto-detect device
    if args.device is None:
        if torch.cuda.is_available():
            device = 'cuda'
        elif torch.backends.mps.is_available():
            device = 'mps'
        else:
            device = 'cpu'
    else:
        device = args.device
    
    print(f"Using device: {device}")
    
    # Validate arguments
    if args.models and args.model_names and args.model_types:
        if not (len(args.models) == len(args.model_names) == len(args.model_types)):
            raise ValueError("Number of models, names, and types must match")
    
    results = {}
    
    # Evaluate each model
    if args.models:
        for model_path, model_name, model_type in zip(args.models, args.model_names, args.model_types):
            print(f"\n{'='*80}")
            print(f"EVALUATING: {model_name}")
            print(f"{'='*80}")
            
            if model_type in ["cnn", "hybrid"]:
                result = evaluate_resnet(
                    model_path, args.data_root, split=args.split,
                    num_classes=args.num_classes, batch_size=args.batch_size,
                    device=device, model_arch=args.model_arch, detailed=args.detailed
                )
            elif model_type == "fewshot":
                result = evaluate_fewshot_encoder(
                    model_path, args.data_root, split=args.split,
                    batch_size=args.batch_size, device=device, detailed=args.detailed
                )
            else:
                raise ValueError(f"Unknown model type: {model_type}")
            
            results[model_name] = result
    
    # Compare models if multiple were evaluated
    if len(results) > 1:
        compare_models(results)
    
    print(f"\nEvaluation complete!")

if __name__ == "__main__":
    main()