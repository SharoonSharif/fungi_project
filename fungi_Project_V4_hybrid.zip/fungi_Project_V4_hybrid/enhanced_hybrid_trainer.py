import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, WeightedRandomSampler
from model import get_model
from data_loader import FungiDataset, get_class_counts
from tqdm import tqdm
import os
import pandas as pd

def get_actual_num_classes(data_root):
    """Get the actual number of classes by checking both train and val sets"""
    train_csv = os.path.join(data_root, "train.csv")
    val_csv = os.path.join(data_root, "val.csv")
    
    train_df = pd.read_csv(train_csv)
    val_df = pd.read_csv(val_csv)
    
    all_labels = set(train_df['label'].unique()) | set(val_df['label'].unique())
    max_label = max(all_labels)
    
    print(f"Train classes: {train_df['label'].nunique()}")
    print(f"Val classes: {val_df['label'].nunique()}")
    print(f"Max label found: {max_label}")
    print(f"Total unique classes: {len(all_labels)}")
    
    # Return max_label + 1 to accommodate 0-indexed labels
    return max_label + 1

def evaluate_model(model, dataloader, device):
    """Evaluate model and return accuracy and loss"""
    model.eval()
    correct, total, total_loss = 0, 0, 0.0
    criterion = nn.CrossEntropyLoss()
    
    with torch.no_grad():
        for images, labels in dataloader:
            images, labels = images.to(device), labels.to(device)
            
            # Clamp labels to valid range
            num_classes = model.fc.out_features
            labels = torch.clamp(labels, 0, num_classes - 1)
            
            logits = model(images)
            loss = criterion(logits, labels)
            
            total_loss += loss.item() * images.size(0)
            preds = logits.argmax(dim=1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)
    
    accuracy = correct / total
    avg_loss = total_loss / total
    return accuracy, avg_loss

def train_stage(model, train_loader, val_loader, optimizer, loss_fn, device, 
                freeze_backbone=False, epochs=10, stage_name="Training"):
    """Train model for one stage with optional backbone freezing"""
    if freeze_backbone:
        print(f"🔒 Freezing backbone for {stage_name}")
        for name, param in model.named_parameters():
            if 'fc' not in name:
                param.requires_grad = False
            else:
                param.requires_grad = True
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print(f"   Trainable parameters: {trainable_params:,}")
    else:
        print(f"🔥 Training all parameters for {stage_name}")
        for param in model.parameters():
            param.requires_grad = True
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print(f"   Trainable parameters: {trainable_params:,}")

    best_val_acc = 0.0
    
    for epoch in range(epochs):
        model.train()
        running_loss, correct, total = 0.0, 0, 0
        
        progress_bar = tqdm(train_loader, desc=f"{stage_name} Epoch {epoch+1}/{epochs}")
        for images, labels in progress_bar:
            images, labels = images.to(device), labels.to(device)
            
            # Clamp labels to valid range
            num_classes = model.fc.out_features
            labels = torch.clamp(labels, 0, num_classes - 1)
            
            optimizer.zero_grad()
            logits = model(images)
            loss = loss_fn(logits, labels)
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item() * images.size(0)
            preds = logits.argmax(dim=1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)
            
            # Update progress bar with percentage
            current_acc = 100 * correct / total
            progress_bar.set_postfix({
                'Loss': f'{loss.item():.3f}',
                'Acc': f'{current_acc:.1f}%'
            })
        
        train_acc = correct / total
        avg_loss = running_loss / total
        
        # Validation
        val_acc, val_loss = evaluate_model(model, val_loader, device)
        
        print(f"\n{stage_name} Epoch {epoch+1}/{epochs}")
        print(f"  📈 Train - Loss: {avg_loss:.3f}, Acc: {100*train_acc:.1f}%")
        print(f"  📊 Val   - Loss: {val_loss:.3f}, Acc: {100*val_acc:.1f}%")
        
        # Save best model
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            model_name = f"best_{stage_name.lower().replace(' ', '_')}_model.pth"
            torch.save(model.state_dict(), model_name)
            print(f"  ⭐ NEW BEST: {100*val_acc:.1f}% - saved as {model_name}")
        
        print("-" * 60)
    
    return model, best_val_acc

def run_hybrid_training(data_root, num_classes=None, batch_size=32, 
                       epochs_stage1=8, epochs_stage2=5, device='mps', model_arch='resnet18'):
    """Run the working two-stage hybrid training approach"""
    print("🍄" + "="*58 + "🍄")
    print("   WORKING HYBRID LONG-TAIL TRAINING FOR FUNGI")
    print("🍄" + "="*58 + "🍄")
    print(f"Device: {device}")
    print(f"Architecture: {model_arch}")
    print(f"Batch size: {batch_size}")
    print(f"Stage 1 epochs: {epochs_stage1}")
    print(f"Stage 2 epochs: {epochs_stage2}")
    print("-"*60)
    
    # Auto-detect number of classes
    if num_classes is None:
        num_classes = get_actual_num_classes(data_root)
    
    print(f"Detected classes: {num_classes}")
    
    # Get class counts for loss weighting (use training set only)
    class_counts = get_class_counts(data_root, split="train")
    
    # Ensure class_counts has the right length
    if len(class_counts) < num_classes:
        class_counts.extend([1] * (num_classes - len(class_counts)))
    elif len(class_counts) > num_classes:
        class_counts = class_counts[:num_classes]
    
    print(f"Dataset statistics:")
    print(f"  📊 Total samples: {sum(class_counts):,}")
    print(f"  📊 Classes: {len(class_counts)}")
    print(f"  🔥 Head classes (≥50): {sum(c >= 50 for c in class_counts)}")
    print(f"  📈 Medium classes (10-49): {sum(10 <= c < 50 for c in class_counts)}")
    print(f"  📉 Tail classes (<10): {sum(c < 10 for c in class_counts)}")
    print(f"  🦴 Zero classes: {sum(c == 0 for c in class_counts)}")
    print("-"*60)
    
    # Create model
    model = get_model(model_arch, num_classes=num_classes, pretrained=True).to(device)
    total_params = sum(p.numel() for p in model.parameters())
    print(f"Model created: {total_params:,} parameters")
    
    # Create datasets
    train_ds = FungiDataset(data_root, split='train')
    val_ds = FungiDataset(data_root, split='val')
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False, num_workers=2, pin_memory=False)
    
    print(f"Train dataset: {len(train_ds):,} samples")
    print(f"Val dataset: {len(val_ds):,} samples")
    print("-"*60)
    
    # --- STAGE 1: Representation Learning with Weighted CrossEntropy ---
    print("🎯 STAGE 1: REPRESENTATION LEARNING")
    print("- ✅ Using weighted CrossEntropy (stable and effective)")
    print("- ✅ Higher learning rate for faster convergence")
    print("- ✅ No conflicting sampling strategies")
    print("- ✅ Reasonable class weight capping to prevent instability")
    
    # Calculate sensible class weights (capped to prevent instability)
    weights = []
    for count in class_counts:
        if count == 0:
            weights.append(1.0)  # Default weight for missing classes
        else:
            # More reasonable scaling: sqrt of inverse frequency, capped at 5x
            weight = min(5.0, (100.0 / count) ** 0.5)
            weights.append(weight)
    
    class_weights = torch.FloatTensor(weights).to(device)
    weighted_ce_loss = nn.CrossEntropyLoss(weight=class_weights)
    
    print(f"Class weights - Min: {min(weights):.2f}, Max: {max(weights):.2f}, Mean: {sum(weights)/len(weights):.2f}")
    
    # Regular training loader with shuffle (no weighted sampling conflicts)
    train_loader1 = DataLoader(
        train_ds, batch_size=batch_size, shuffle=True,
        num_workers=2, pin_memory=False
    )
    
    # Higher learning rate for faster convergence
    optimizer1 = optim.Adam(model.parameters(), lr=5e-3, weight_decay=1e-4)
    
    print(f"Stage 1 optimizer: lr={5e-3}, weight_decay={1e-4}")
    print(f"Batches per epoch: {len(train_loader1)}")
    
    model, stage1_best_acc = train_stage(
        model, train_loader1, val_loader, optimizer1, weighted_ce_loss, device, 
        freeze_backbone=False, epochs=epochs_stage1, stage_name="Stage 1"
    )
    
    print(f"✅ Stage 1 completed. Best validation accuracy: {100*stage1_best_acc:.1f}%")
    print("="*60)
    
    # --- STAGE 2: Classifier Fine-tuning for Tail Classes ---
    print("🎯 STAGE 2: CLASSIFIER FINE-TUNING")
    print("- 🔒 Freeze backbone, train classifier only")
    print("- 📈 Focus on tail classes with weighted sampling")
    print("- 🎯 Lower learning rate for fine-tuning")
    
    # Create weighted sampler that emphasizes tail classes
    sample_weights = []
    for count in class_counts:
        if count == 0:
            sample_weights.extend([1.0])  # Handle zero-count classes
        elif count < 10:  # Tail classes
            sample_weights.extend([3.0] * count)  # 3x weight for tail
        elif count < 50:  # Medium classes
            sample_weights.extend([1.5] * count)  # 1.5x weight for medium
        else:  # Head classes
            sample_weights.extend([1.0] * count)  # Normal weight for head
    
    # Ensure sample_weights length matches dataset
    if len(sample_weights) != len(train_ds):
        print(f"Adjusting sample weights: {len(sample_weights)} -> {len(train_ds)}")
        sample_weights = sample_weights[:len(train_ds)]
    
    train_loader2 = DataLoader(
        train_ds, batch_size=batch_size,
        sampler=WeightedRandomSampler(sample_weights, len(train_ds), replacement=True),
        num_workers=2, pin_memory=False
    )
    
    # Only optimize classifier parameters
    classifier_params = [p for name, p in model.named_parameters() if 'fc' in name]
    trainable_classifier_params = sum(p.numel() for p in classifier_params)
    
    optimizer2 = optim.Adam(classifier_params, lr=2e-3, weight_decay=1e-4)
    
    # Standard CrossEntropy for fine-tuning (no class weights to avoid conflicts with sampling)
    ce_loss = nn.CrossEntropyLoss()
    
    print(f"Stage 2 optimizer: lr={2e-3}, classifier params: {trainable_classifier_params:,}")
    print(f"Tail class weighting: 3x tail, 1.5x medium, 1x head")
    
    model, stage2_best_acc = train_stage(
        model, train_loader2, val_loader, optimizer2, ce_loss, device, 
        freeze_backbone=True, epochs=epochs_stage2, stage_name="Stage 2"
    )
    
    print(f"✅ Stage 2 completed. Best validation accuracy: {100*stage2_best_acc:.1f}%")
    
    # Save final model
    final_model_path = "hybrid_longtail_final.pth"
    torch.save(model.state_dict(), final_model_path)
    
    print("🍄" + "="*58 + "🍄")
    print("🎉 HYBRID TRAINING COMPLETE!")
    print(f"📊 Stage 1 best accuracy: {100*stage1_best_acc:.1f}%")
    print(f"📊 Stage 2 best accuracy: {100*stage2_best_acc:.1f}%")
    print(f"💾 Final model saved as: {final_model_path}")
    
    # Performance summary
    improvement = ((stage2_best_acc - stage1_best_acc) / stage1_best_acc * 100) if stage1_best_acc > 0 else 0
    print(f"📈 Stage 2 improvement: {improvement:+.1f}%")
    print("🍄" + "="*58 + "🍄")
    
    return model, stage1_best_acc, stage2_best_acc

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Working Hybrid Long-Tail Training")
    parser.add_argument("data_root", type=str, help="Root path to data")
    parser.add_argument("--epochs_stage1", type=int, default=8, help="Stage 1 epochs")
    parser.add_argument("--epochs_stage2", type=int, default=5, help="Stage 2 epochs")
    parser.add_argument("--batch_size", type=int, default=32, help="Batch size")
    parser.add_argument("--num_classes", type=int, default=None, help="Number of classes (auto-detect if None)")
    parser.add_argument("--model_arch", type=str, default="resnet18", choices=["resnet18", "resnet50"])
    parser.add_argument("--device", type=str, default=None, help="Device (cuda/cpu/mps/auto)")
    
    args = parser.parse_args()
    
    # Auto-detect device if not specified
    if args.device is None:
        if torch.cuda.is_available():
            device = 'cuda'
        elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
            device = 'mps'
        else:
            device = 'cpu'
    else:
        device = args.device
    
    run_hybrid_training(
        args.data_root, 
        num_classes=args.num_classes,
        batch_size=args.batch_size,
        epochs_stage1=args.epochs_stage1, 
        epochs_stage2=args.epochs_stage2,
        device=device,
        model_arch=args.model_arch
    )