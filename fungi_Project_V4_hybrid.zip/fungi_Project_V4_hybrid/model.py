import torch
import torch.nn as nn
import torchvision.models as models

def get_model(arch='resnet50', num_classes=488, pretrained=True):
    """
    Returns a ResNet model with the specified architecture, number of output classes,
    and option to load ImageNet weights.
    """
    if arch == 'resnet50':
        model = models.resnet50(pretrained=pretrained)
    elif arch == 'resnet18':
        model = models.resnet18(pretrained=pretrained)
    else:
        raise ValueError(f"Unsupported architecture: {arch}")

    # Replace the final fully connected layer to match the number of classes
    in_features = model.fc.in_features
    model.fc = nn.Linear(in_features, num_classes)
    return model

def freeze_backbone(model):
    """
    Freezes all layers except the classifier head (useful for fine-tuning).
    Assumes classifier is named 'fc' (ResNet-style).
    """
    for name, param in model.named_parameters():
        if not name.startswith('fc'):
            param.requires_grad = False
        else:
            param.requires_grad = True

def unfreeze_all(model):
    """
    Unfreezes all parameters for full-model training.
    """
    for param in model.parameters():
        param.requires_grad = True

# (OPTIONAL) For few-shot learning: simple feature encoder (can be adapted)
class FeatureEncoder(nn.Module):
    def __init__(self, base='resnet18', pretrained=True, out_dim=512):
        super().__init__()
        if base == 'resnet18':
            backbone = models.resnet18(pretrained=pretrained)
            self.features = nn.Sequential(*list(backbone.children())[:-1])
            self.out_dim = backbone.fc.in_features
        elif base == 'resnet50':
            backbone = models.resnet50(pretrained=pretrained)
            self.features = nn.Sequential(*list(backbone.children())[:-1])
            self.out_dim = backbone.fc.in_features
        else:
            raise ValueError(f"Unknown backbone: {base}")
        self.fc = nn.Identity()

    def forward(self, x):
        x = self.features(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x

# (OPTIONAL) For prototypical networks
class ProtoNetHead(nn.Module):
    def __init__(self):
        super().__init__()
    def forward(self, support, query):
        # support: [n_way*k_shot, feat_dim]
        # query: [n_query, feat_dim]
        # L2 distance
        dists = torch.cdist(query, support.mean(dim=0, keepdim=True))
        return -dists

# Helper for hybrid training (stage-based freezing)
def set_trainable_layers(model, freeze_backbone=True):
    """
    Freeze/unfreeze backbone for hybrid training.
    If freeze_backbone: only classifier is trainable.
    If not: all layers trainable.
    """
    if freeze_backbone:
        freeze_backbone(model)
    else:
        unfreeze_all(model)

# Utility for counting parameters
def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

# Example usage:
if __name__ == "__main__":
    model = get_model('resnet50', num_classes=488)
    print("Trainable params (all):", count_parameters(model))
    freeze_backbone(model)
    print("Trainable params (classifier only):", count_parameters(model))
