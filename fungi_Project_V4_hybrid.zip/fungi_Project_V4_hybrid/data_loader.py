import os
import torch
from torch.utils.data import Dataset
from PIL import Image
import pandas as pd
from collections import Counter
import numpy as np
import torchvision.transforms as T

class FungiDataset(Dataset):
    """
    Standard image dataset for fungi classification.
    Expects a CSV with columns: filepath,label.
    Always returns images as tensors.
    """
    def __init__(self, data_root, split='train', transform=None):
        super().__init__()
        self.data_root = data_root
        self.split = split
        self.csv_path = os.path.join(data_root, f"{split}.csv")
        self.data = pd.read_csv(self.csv_path)
        # Default transform (guaranteed ToTensor)
        if transform is None:
            self.transform = T.Compose([
                T.Resize((224, 224)),
                T.ToTensor(),
            ])
        else:
            self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        img_path = os.path.join(self.data_root, self.data.iloc[idx]['filepath'])
        label = int(self.data.iloc[idx]['label'])
        image = Image.open(img_path).convert("RGB")
        image = self.transform(image)
        return image, label

def get_class_counts(data_root, split='train'):
    """
    Returns a list of sample counts per class for a given split.
    """
    csv_path = os.path.join(data_root, f"{split}.csv")
    data = pd.read_csv(csv_path)
    counts = Counter(data['label'])
    num_classes = max(counts.keys()) + 1
    class_counts = [counts.get(i, 0) for i in range(num_classes)]
    return class_counts

def get_sampler_weights(class_counts, mode='inv_freq', tail_threshold=10, tail_weight=5):
    """
    Returns per-sample weights for WeightedRandomSampler.
    mode:
        - 'inv_freq': 1/frequency (default, for class balancing)
        - 'tail': heavier weight for tail classes
        - 'balanced': combination of inverse frequency with tail boosting
    """
    weights = []
    
    for i, count in enumerate(class_counts):
        if count == 0:
            w = 0.0
        elif mode == 'inv_freq':
            w = 1.0 / count
        elif mode == 'tail':
            w = tail_weight if count < tail_threshold else 1.0
        elif mode == 'balanced':
            # Combine inverse frequency with tail boosting
            base_weight = 1.0 / count
            tail_boost = tail_weight if count < tail_threshold else 1.0
            w = base_weight * tail_boost
        else:
            w = 1.0
        weights.append(w)
    
    # Create per-sample weights by reading the CSV again
    csv_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                           'data', 'split_mind_funga', 'train.csv')
    
    # Alternative: create sample weights by expanding class weights
    sample_weights = []
    csv_path = None
    
    # Find the CSV file - try common locations
    possible_paths = [
        'train.csv',
        'data/split_mind_funga/train.csv',
        '../data/split_mind_funga/train.csv'
    ]
    
    for path in possible_paths:
        if os.path.exists(path):
            csv_path = path
            break
    
    if csv_path and os.path.exists(csv_path):
        # Read CSV to get actual sample order
        data = pd.read_csv(csv_path)
        sample_weights = [weights[int(label)] for label in data['label']]
    else:
        # Fallback: create weights by expanding class counts
        for class_idx, count in enumerate(class_counts):
            sample_weights.extend([weights[class_idx]] * count)
    
    return torch.DoubleTensor(sample_weights)

def create_csv_from_directory_structure(data_root, output_csv='train.csv'):
    """
    Create CSV file from directory structure if it doesn't exist.
    Assumes structure: data_root/class_name/image_files
    """
    data = []
    
    for class_name in os.listdir(data_root):
        class_path = os.path.join(data_root, class_name)
        if not os.path.isdir(class_path):
            continue
            
        # Convert class name to numeric label
        try:
            class_label = int(class_name)
        except ValueError:
            # If class name is not numeric, create mapping
            continue
            
        for img_file in os.listdir(class_path):
            if img_file.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
                relative_path = os.path.join(class_name, img_file)
                data.append({'filepath': relative_path, 'label': class_label})
    
    df = pd.DataFrame(data)
    df.to_csv(os.path.join(data_root, output_csv), index=False)
    print(f"Created {output_csv} with {len(df)} samples")
    return df

class FewShotEpisodeDataset(Dataset):
    """
    Dataset for N-way K-shot episodic few-shot learning.
    """
    def __init__(self, data_root, N_way, K_shot, Q_query, split='train', transform=None):
        super().__init__()
        self.data_root = data_root
        self.split = split
        self.N_way = N_way
        self.K_shot = K_shot
        self.Q_query = Q_query
        self.transform = transform

        csv_path = os.path.join(data_root, f"{split}.csv")
        if not os.path.exists(csv_path):
            print(f"CSV file {csv_path} not found. Attempting to create from directory structure...")
            create_csv_from_directory_structure(
                os.path.join(data_root, split), 
                f"{split}.csv"
            )
        
        data = pd.read_csv(csv_path)
        self.label_to_indices = {}
        for label in data['label'].unique():
            self.label_to_indices[label] = data[data['label']==label].index.tolist()
        
        # Filter out classes with insufficient samples
        min_samples_needed = self.K_shot + self.Q_query
        valid_labels = [label for label, indices in self.label_to_indices.items() 
                       if len(indices) >= min_samples_needed]
        
        self.labels = valid_labels
        self.data = data
        
        excluded_count = len(self.label_to_indices) - len(valid_labels)
        if excluded_count > 0:
            print(f"Warning: {excluded_count} classes excluded due to insufficient samples "
                  f"(need {min_samples_needed}, have {self.K_shot + self.Q_query})")

    def __len__(self):
        # Arbitrary, usually number of episodes per epoch
        return 1000

    def __getitem__(self, episode_idx):
        if len(self.labels) < self.N_way:
            raise ValueError(f"Not enough valid classes ({len(self.labels)}) for {self.N_way}-way episodes")
            
        selected_labels = np.random.choice(self.labels, self.N_way, replace=False)
        support_images, support_labels = [], []
        query_images, query_labels = [], []
        
        for idx, label in enumerate(selected_labels):
            indices = self.label_to_indices[label]
            # Sample without replacement if possible
            if len(indices) >= self.K_shot + self.Q_query:
                selected = np.random.choice(indices, self.K_shot + self.Q_query, replace=False)
            else:
                selected = np.random.choice(indices, self.K_shot + self.Q_query, replace=True)
                
            for i in range(self.K_shot):
                img_path = os.path.join(self.data_root, self.data.iloc[selected[i]]['filepath'])
                img = Image.open(img_path).convert("RGB")
                if self.transform:
                    img = self.transform(img)
                support_images.append(img)
                support_labels.append(idx)
                
            for i in range(self.K_shot, self.K_shot + self.Q_query):
                img_path = os.path.join(self.data_root, self.data.iloc[selected[i]]['filepath'])
                img = Image.open(img_path).convert("RGB")
                if self.transform:
                    img = self.transform(img)
                query_images.append(img)
                query_labels.append(idx)
                
        return (torch.stack(support_images), torch.tensor(support_labels),
                torch.stack(query_images), torch.tensor(query_labels))

def dataset_summary(data_root, split='train'):
    """
    Print summary statistics for a split.
    """
    class_counts = get_class_counts(data_root, split)
    print(f"Split: {split}")
    print(f"Classes: {len(class_counts)}, Samples: {sum(class_counts)}")
    print("Head (>=50 samples):", sum([c>=50 for c in class_counts]))
    print("Medium (10-49):", sum([10<=c<50 for c in class_counts]))
    print("Tail (<10):", sum([c<10 for c in class_counts]))
    print("Classes with 0 samples:", sum([c==0 for c in class_counts]))
    print("Per-class counts (first 20):", class_counts[:20])
    
    # Additional statistics
    non_zero_counts = [c for c in class_counts if c > 0]
    if non_zero_counts:
        print(f"Min samples per class: {min(non_zero_counts)}")
        print(f"Max samples per class: {max(non_zero_counts)}")
        print(f"Mean samples per class: {np.mean(non_zero_counts):.1f}")
        print(f"Median samples per class: {np.median(non_zero_counts):.1f}")

# Example: test this file standalone
if __name__ == "__main__":
    data_root = "data/split_mind_funga"
    if os.path.exists(data_root):
        dataset_summary(data_root, 'train')
        dataset_summary(data_root, 'val')
    else:
        print(f"Data directory {data_root} not found")
        print("Please run setup_data.py first to create the split dataset")